package com.example.zing.Service

class DataService {
}