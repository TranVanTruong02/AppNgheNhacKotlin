package com.example.zing.Utils

class CheckInternet {
}