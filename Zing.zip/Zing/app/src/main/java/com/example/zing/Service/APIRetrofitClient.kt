package com.example.zing.Service

// Khởi tạo retrofit để tương tác với server
class APIRetrofitClient {

    // Cấu hình cho retrofit
    private val retrofit: Retrofit by lazy {
        // Gán lại
        Retrofit.Builder()
            .baseUrl(base_url) // Nhận đường dẫn
            .client(okHttpClient) // Nhận các phương thức, giao thức mạng
            .addConverterFactory(GsonConverterFactory.create()) // Còn vợt dữ liệu API thành biến của java
            .build()
    }

    // Khởi tạo funsion cho việc trả dữ liệu về
    fun getClient(base_url: String): Retrofit {
        // Giao thức, các tương tác mạng sẽ thông qua OkHttpClient
        val okHttpClient = OkHttpClient.Builder() // Kiểm tra mạng và các giao thức
            .readTimeout(10000, TimeUnit.MILLISECONDS) // Thời gian ngắt khi đợi quá lâu
            .writeTimeout(10000, TimeUnit.MILLISECONDS)
            .connectTimeout(10000, TimeUnit.MILLISECONDS) // chờ quá lâu sẽ ngắt kết nối
            .retryOnConnectionFailure(true) // nếu lỗi mạng nó sẽ cố gắng kết nối lại
            .protocols(listOf(Protocol.HTTP_1_1)) // sét lại giao thức tránh gây lỗi
            .build()

        // sử dụng đọc dữ liệu trên server về
        val gson = GsonBuilder().setLenient().create()

        return retrofit
    }
}
