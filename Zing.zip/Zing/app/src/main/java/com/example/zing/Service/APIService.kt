package com.example.zing.Service

// Kết hợp 2 function APIRetrofitcline và DataService
class APIService {
    // Truyền địa chỉ url
    private val baseUrl = "https://appnghenhac2023.000webhostapp.com/Server_Zing/"

    companion object {
        fun getService(): DataService {
            return APIRetrofitClient.getClient(baseUrl).create(DataService::class.java)
        }
    }
}
