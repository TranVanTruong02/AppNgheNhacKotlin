package com.example.zing.Utils

class PaginationScrollListener {
}